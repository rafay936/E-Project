<?php
$host = 'localhost';
$db = 'vms_db';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $request_id = (int)$_GET['id'];

    $check_query = "SELECT status FROM vaccine_requests WHERE id = $request_id";
    $check_result = $conn->query($check_query);
    $row = $check_result->fetch_assoc();

    if ($row && $row['status'] === 'Pending') {
        $status = ($action === 'approve') ? 'Approved' : 'Rejected';
        $update_query = "UPDATE vaccine_requests SET status = '$status' WHERE id = $request_id";

        if ($conn->query($update_query) === TRUE) {
            echo "<p class='success'>Request $status successfully!</p>";
        } else {
            echo "<p class='error'>Error updating status: " . $conn->error . "</p>";
        }
    }
}

$requests_query = "SELECT * FROM vaccine_requests ORDER BY request_date DESC";
$requests_result = $conn->query($requests_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccine Requests - Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
            line-height: 1.6;
        }
        header {
            background-color: #007bff;
            padding: 15px;
            text-align: center;
        }
        nav {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        header a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, transform 0.2s ease-in-out;
        }
        header a:hover {
            background-color: #0056b3;
            transform: scale(1.1);
        }
        header a.active {
            background-color:rgb(162, 253, 159);
            color: black;
            font-weight: bold;
        }
        h1 {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }
        table {
            width: 90%;
            border-collapse: collapse;
            margin: 20px auto;
            background: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease-in-out;
        }
        .success {
            color: green;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
        }
        .status {
            font-weight: bold;
            text-transform: capitalize;
        }
        .status.approved {
            color: green;
        }
        .status.rejected {
            color: red;
        }
        a {
            display: inline-block;
            margin: 5px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, transform 0.2s ease-in-out;
        }
        a:hover {
            background-color: #0056b3;
            transform: scale(1.1);
        }
        .disabled {
            pointer-events: none;
            opacity: 0.6;
            background-color: yellow;
        }
    </style>
</head>
<body>

<header>
    <nav>
        <a href="index.php">Home</a>
        <a href="vaccines.php">Vaccine Reports</a>
        <a href="vaccine_requests.php" class="active">Vaccine Requests</a>
    </nav>
</header>

<h1>Vaccine Requests From Hospitals - Admin Panel</h1>

<h2 style="text-align: center;">Vaccine Requests</h2>
<table>
    <tr>
        <th>Requester Name</th>
        <th>Vaccine</th>
        <th>Quantity</th>
        <th>Request Date</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $requests_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['requester_name'] ?></td>
            <td><?= $row['vaccine_name'] ?></td>
            <td><?= $row['quantity'] ?></td>
            <td><?= $row['request_date'] ?></td>
            <td class="status <?= strtolower($row['status']) ?>"><?= $row['status'] ?></td>
            <td>
                <?php if ($row['status'] === 'Pending'): ?>
                    <a href="?action=approve&id=<?= $row['id'] ?>">Approve</a>
                    <a href="?action=reject&id=<?= $row['id'] ?>">Reject</a>
                <?php else: ?>
                    <span class="disabled"><?= $row['status'] ?></span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>

<?php
$conn->close();
?>
