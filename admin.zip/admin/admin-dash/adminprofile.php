<?php
session_start();

$host = 'localhost';
$db = 'vms_db';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE user_id='$user_id'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="style/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
            line-height: 1.6;
        }
        header {
            background-color: #007bff;
            padding: 15px;
            text-align: center;
        }
        nav {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        header a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, transform 0.2s ease-in-out;
        }
        header a:hover {
            background-color: #0056b3;
            transform: scale(1.1);
        }
        header a.active {
            background-color:rgb(162, 253, 159);
            color: black;
            font-weight: bold;
        }
        h1 {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }
        table {
            width: 90%;
            border-collapse: collapse;
            margin: 20px auto;
            background: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease-in-out;
        }
        .success {
            color: green;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
        }
        .status {
            font-weight: bold;
            text-transform: capitalize;
        }
        .status.approved {
            color: green;
        }
        .status.rejected {
            color: red;
        }
        a {
            display: inline-block;
            margin: 5px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, transform 0.2s ease-in-out;
        }
        a:hover {
            background-color: #0056b3;
            transform: scale(1.1);
        }
        .disabled {
            pointer-events: none;
            opacity: 0.6;
            background-color: yellow;
        } 
        .header {
            background: #007bff;
            color: #fff;
            padding: 20px;
            text-align: center;
            font-size: 24px;
        }
        .profile-box {
            background: #fff;
            padding: 20px;
            margin-top: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .profile-box img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            display: block;
            margin: 0 auto 10px;
        }
        .profile-box h2 {
            text-align: center;
            color: #333;
        }
        .profile-info {
            text-align: center;
            font-size: 18px;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="header">Admin Profile
    
    <a href="index.php">Home</a>
        <a href="vaccines.php">Vaccine Reports</a>
        <a href="Vaccine Requests.php" >Vaccine Requests</a>
    </div>
    <div class="container">
        <div class="profile-box">
            <img src="images/admin.png" alt="Profile Picture">
            <h2><?php echo $user['full_name']; ?></h2>
            <div class="profile-info">
                <p><strong>Username:</strong> <?php echo $user['username']; ?></p>
                <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
                <p><strong>Phone:</strong> <?php echo $user['phone']; ?></p>
                <p><strong>Address:</strong> <?php echo $user['address']; ?></p>
                <p><strong>Role:</strong> <?php echo ucfirst($user['role']); ?></p>
            </div>
        </div>
    </div>
</body>
</html>
