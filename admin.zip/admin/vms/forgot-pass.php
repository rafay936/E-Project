<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot password</title>
       <!-- custom css link -->
      <link rel="stylesheet" href="style/style.css">
</head>
<body>
     <!-- main form container -->
      <div class="container">
        <div class="box form-box">
            <h6>Forgot your password?</h6>
            <form action="" method="post">
                <div class="field input">
                    <label for="email">Email</label>
                    <input type="text" name="email" id="email" autocomplete="off" required>
                </div>
                 <!-- submit and back btn -->
                <div class="field">
                    <input type="submit" class="btn" name="submit" value="Confirm" require> 
                    <input type="submit" class="btn" name="submit" value="Back" require> 
                </div>
              
            </form>
        </div>
      </div>
</body>
</html>